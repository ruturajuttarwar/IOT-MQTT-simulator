import { TrendingUp } from 'lucide-react'

export default function MetricsPanel({ metrics }) {
  if (!metrics) {
    return (
      <div className="card">
        <div className="card-header flex items-center space-x-2">
          <TrendingUp className="w-5 h-5 text-blue-600" />
          <span>Performance Metrics</span>
        </div>
        <div className="card-body">
          <p className="text-gray-500 text-sm">No metrics available</p>
        </div>
      </div>
    )
  }

  return (
    <div className="card">
      <div className="card-header flex items-center space-x-2">
        <TrendingUp className="w-5 h-5 text-blue-600" />
        <span>Performance Metrics</span>
      </div>
      <div className="card-body">
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">Total Messages</span>
            <span className="font-semibold text-lg">{metrics.total_messages_sent || 0}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">Avg Latency</span>
            <span className="font-semibold text-blue-600">
              {metrics.average_latency?.toFixed(2) || 0} ms
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">Throughput</span>
            <span className="font-semibold text-green-600">
              {metrics.throughput?.toFixed(2) || 0} msg/s
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">Packet Loss</span>
            <span className="font-semibold text-red-600">
              {metrics.packet_loss_rate?.toFixed(2) || 0}%
            </span>
          </div>
        </div>
      </div>
    </div>
  )
}
