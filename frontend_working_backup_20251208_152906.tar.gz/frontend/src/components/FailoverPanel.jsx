import { Shield } from 'lucide-react'

export default function FailoverPanel({ failoverStats }) {
  if (!failoverStats) {
    return (
      <div className="card">
        <div className="card-header flex items-center space-x-2">
          <Shield className="w-5 h-5 text-blue-600" />
          <span>Failover Status</span>
        </div>
        <div className="card-body">
          <p className="text-gray-500 text-sm">No failover data available</p>
        </div>
      </div>
    )
  }

  return (
    <div className="card">
      <div className="card-header flex items-center space-x-2">
        <Shield className="w-5 h-5 text-blue-600" />
        <span>Failover Status</span>
      </div>
      <div className="card-body">
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">Total Failovers</span>
            <span className="font-semibold text-lg">{failoverStats.total_failovers || 0}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">Active Brokers</span>
            <span className="font-semibold text-green-600">{failoverStats.active_brokers || 0}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">Failed Brokers</span>
            <span className="font-semibold text-red-600">{failoverStats.failed_brokers || 0}</span>
          </div>
        </div>
      </div>
    </div>
  )
}
